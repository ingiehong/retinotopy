function lic = actxlicense(progid)

if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.System')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Image')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Application')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Digitizer')
lic = 'Matrox Electonics Ltd.';
return;
end
if strcmpi(progid, 'MIL.Display')
lic = 'Matrox Electonics Ltd.';
return;
end